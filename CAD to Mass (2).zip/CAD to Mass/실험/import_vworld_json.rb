require 'json'

module VworldJSONImporter
  def self.load_data
    # 1. 파일 선택
    # 주의: 한글 경로 지원을 위해 File.expand_path 사용 등이 필요할 수 있으나,
    # 사용자 편의를 위해 UI.openpanel을 사용합니다.
    default_path = File.join(ENV['USERPROFILE'] || ENV['HOME'], "Downloads", "vworld_parsed_data.json")
    if File.exist?(default_path)
      file_path = default_path
    else
      file_path = UI.openpanel("VWorld JSON 파일 선택", "", "JSON Files|*.json;||")
    end
    
    return unless file_path
    
    begin
      file_content = File.read(file_path, encoding: "utf-8")
      data = JSON.parse(file_content)
      generate_model(data)
    rescue => e
      UI.messagebox("JSON 로드 중 오류 발생:\n#{e.message}")
    end
  end

  def self.extract_pts(coordinates)
    return [] if coordinates.nil? || coordinates.empty?
    
    if coordinates[0][0].is_a?(Array) && coordinates[0][0][0].is_a?(Array)
      # MultiPolygon / MultiLineString ([[[[x, y]]]])
      return coordinates[0][0]
    elsif coordinates[0][0].is_a?(Array)
      # Polygon ([[[x, y]]])
      return coordinates[0]
    else
      # LineString ([[x, y]])
      return coordinates
    end
  end

  def self.generate_model(data)
    model = Sketchup.active_model
    model.start_operation('Import VWorld GeoJSON', true)

    # 중심 좌표 (Origin) 구하기
    center_lng = nil
    center_lat = nil

    if data['buildings'] && !data['buildings'].empty?
      pts = extract_pts(data['buildings'][0]['coordinates'])
      center_lng = pts[0][0]
      center_lat = pts[0][1]
    elsif data['roads'] && !data['roads'].empty?
      pts = extract_pts(data['roads'][0]['coordinates'])
      center_lng = pts[0][0]
      center_lat = pts[0][1]
    elsif data['contours'] && !data['contours'].empty?
      pts = extract_pts(data['contours'][0]['coordinates'])
      center_lng = pts[0][0]
      center_lat = pts[0][1]
    else
      UI.messagebox("JSON 파일에 유효한 지오메트리 데이터가 없습니다.")
      model.abort_operation
      return
    end

    # 1. 건물 (Buildings) 생성
    if data['buildings']
      building_group = model.entities.add_group
      building_group.name = "건물_Buildings"
      building_group.layer = model.layers.add("VWorld_Buildings")
      
      data['buildings'].each do |b|
        height_m = b['height'].to_f
        height_m = 3.0 if height_m <= 0
        height_in = height_m.m
        
        pts = extract_pts(b['coordinates'])
        next if pts.size < 3
        
        pt3ds = pts.map { |c| latlng_to_pt(c[0], c[1], center_lng, center_lat) }
        
        begin
          # 면 생성
          face = building_group.entities.add_face(pt3ds)
          if face
            # 법선이 아래를 향하면 뒤집기 (시계방향/반시계방향 문제)
            face.reverse! if face.normal.z < 0
            
            # 높이만큼 돌출
            face.pushpull(-height_in) # 음수로 넣어야 위로 돌출되는 경우가 많으나, normal.z > 0이면 양수/음수 주의
            
            # 메타데이터 부여
            face.set_attribute("vworld", "name", b["name"])
            face.set_attribute("vworld", "usage", b["usage"])
            face.set_attribute("vworld", "height", b["height"])
          end
        rescue => e
          puts "건물 면 생성 실패 (#{b['name']}): #{e.message}"
        end
      end
    end

    # 2. 도로 생성 (선형)
    if data['roads']
      road_group = model.entities.add_group
      road_group.name = "도로_Roads"
      road_group.layer = model.layers.add("VWorld_Roads")
      
      data['roads'].each do |r|
        pts = extract_pts(r['coordinates'])
        next if pts.size < 2
        
        pt3ds = pts.map { |c| latlng_to_pt(c[0], c[1], center_lng, center_lat) }
        
        # 선 연결
        (0...pt3ds.size-1).each do |i|
           road_group.entities.add_line(pt3ds[i], pt3ds[i+1])
        end
      end
    end

    # 3. 등고선 생성 (선형 및 높이)
    if data['contours']
      contour_group = model.entities.add_group
      contour_group.name = "등고선_Contours"
      contour_group.layer = model.layers.add("VWorld_Contours")
      
      data['contours'].each do |c|
        elev_m = c['elevation'].to_f.m
        pts = extract_pts(c['coordinates'])
        next if pts.size < 2
        
        pt3ds = pts.map { |coord| latlng_to_pt(coord[0], coord[1], center_lng, center_lat, elev_m) }
        
        (0...pt3ds.size-1).each do |i|
           contour_group.entities.add_line(pt3ds[i], pt3ds[i+1])
        end
      end
    end

    model.commit_operation
    model.active_view.zoom_extents
    UI.messagebox("VWorld 지형 데이터 생성 완료!")
  end

  # 경위도(WGS84)를 SketchUp 내부 로컬 좌표(Inches)로 평면 투영
  def self.latlng_to_pt(lng, lat, center_lng, center_lat, elevation = 0.0)
    r = 6378137.0 # 지구 반지름(미터)
    x_m = (lng - center_lng) * (Math::PI / 180.0) * r * Math.cos(center_lat * Math::PI / 180.0)
    y_m = (lat - center_lat) * (Math::PI / 180.0) * r
    
    # SketchUp은 내부적으로 인치(Inch) 단위를 사용하므로 .m 메서드로 변환
    Geom::Point3d.new(x_m.to_f.m, y_m.to_f.m, elevation)
  end
end

# 즉시 실행
VworldJSONImporter.load_data
