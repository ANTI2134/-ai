import requests
import json
import math

# 기본 V-World API 설정
DOMAIN = "localhost" # V-World API 요청시 필수 도메인 (임의 지정 가능)

def calculate_bbox(lng, lat, radius_m):
    """중심 좌표와 반경(m)을 기반으로 Bounding Box (geomFilter 용) 계산"""
    if radius_m <= 0:
        return f"POINT({lng} {lat})"
    
    # 1도는 위도 약 111.32km
    d_lat = radius_m / 111320.0
    d_lng = radius_m / (111320.0 * math.cos(math.radians(lat)))
    
    min_lng = lng - d_lng
    min_lat = lat - d_lat
    max_lng = lng + d_lng
    max_lat = lat + d_lat
    
    return f"BOX({min_lng},{min_lat},{max_lng},{max_lat})"

def fetch_vworld_wfs(api_key, layer_name, geom_filter):
    """V-World Data API (WFS) GeoJSON 요청하여 Feature 리스트 리턴"""
    url = "https://api.vworld.kr/req/data"
    params = {
        "service": "data",
        "version": "2.0",
        "request": "GetFeature",
        "data": layer_name,
        "key": api_key,
        "domain": f"http://{DOMAIN}",
        "geomFilter": geom_filter,
        "crs": "EPSG:4326",
        "size": "1000",
        "format": "json"
    }
    
    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        
        if "response" in data and data["response"]["status"] == "OK":
            if "result" in data["response"] and "featureCollection" in data["response"]["result"]:
                return data["response"]["result"]["featureCollection"]["features"]
    except requests.exceptions.HTTPError as e:
        print(f"⚠️ {layer_name} HTTP 에러: {e}")
    except json.JSONDecodeError:
         print(f"⚠️ {layer_name} 응답 JSON 파싱 실패")
    except Exception as e:
        print(f"⚠️ {layer_name} 조회 에러: {e}")
    
    return []

def parse_vworld_terrain_data(api_key, lng, lat, radius=100):
    """특정 영역의 건물, 도로망, 등고선 데이터를 파싱하여 Python 딕셔너리 객체로 반환"""
    geom_filter = calculate_bbox(lng, lat, radius)
    
    print(f"📡 데이터 조회 요청 시작 (경도: {lng:.6f}, 위도: {lat:.6f}, 반경: {radius}m)")
    
    # 1. 건물 데이터 조회 (LT_C_BSI 최우선, 실패시 LT_C_SPBD 풀백)
    buildings = fetch_vworld_wfs(api_key, "LT_C_BSI", geom_filter)
    if not buildings:
        print("💡 LT_C_BSI 조회 실패/데이터 없음, LT_C_SPBD(국가공간정보 건물)로 대체 시도")
        buildings = fetch_vworld_wfs(api_key, "LT_C_SPBD", geom_filter)
    
    # 2. 도로망(선) 데이터 조회 (LT_L_SPRD)
    roads = fetch_vworld_wfs(api_key, "LT_L_SPRD", geom_filter)
    
    # 3. 등고선 데이터 조회 
    # 주의: VWorld에서 등고선은 대용량 지형데이터라 WFS 실시간 API (GetFeature)로 제공되지 않는 경우가 많습니다.
    # 만약 사설 레이어나 다른 특정 등고선 레이어(LT_L_CONTOUR 등)가 있다면 아래 레이어명을 변경하세요.
    contours = fetch_vworld_wfs(api_key, "LT_L_CONTOUR", geom_filter) 
    
    # 데이터 파싱
    parsed_data = {
        "buildings": [],
        "roads": [],
        "contours": []
    }
    
    # -- 1. 건물 파싱 --
    for b in buildings:
        props = b.get("properties", {})
        
        # 높이 및 층수 속성 추출 (다양한 레이어 포맷 대응)
        hght = float(props.get("buld_hght") or props.get("hght") or props.get("bd_hg") or props.get("BD_HG") or 0)
        floors = int(props.get("grnd_flr") or props.get("gro_flo_co") or props.get("GRO_FLO_CO") or 0)
        
        # 층수/높이 보완 (스케치업 Extrude를 위해 1층 = 3m 기준 설정)
        if hght <= 0 and floors > 0:
            hght = floors * 3.0
        elif floors <= 0 and hght > 0:
            floors = max(1, round(hght / 3.0))
            
        parsed_data["buildings"].append({
            "name": props.get("buld_nm") or props.get("bd_nm") or props.get("BULD_NM") or "무명 건물",
            "usage": props.get("bdtyp_nm") or props.get("prpos_nm") or props.get("MAIN_PURPS_NM") or "분류없음",
            "height": hght,
            "floors": floors,
            "coordinates": b.get("geometry", {}).get("coordinates", [])
        })
        
    # -- 2. 도로망 파싱 --
    for r in roads:
        parsed_data["roads"].append({
            "coordinates": r.get("geometry", {}).get("coordinates", [])
        })
        
    # -- 3. 등고선 파싱 --
    for c in contours:
        props = c.get("properties", {})
        # 등고선의 표고(Elevation) 속성에 맞게 추출
        elevation = float(props.get("elevation") or props.get("val") or props.get("alti") or 0)
        parsed_data["contours"].append({
            "elevation": elevation,
            "coordinates": c.get("geometry", {}).get("coordinates", [])
        })
        
    print(f"✅ 파싱 완료: 건물 {len(parsed_data['buildings'])}개, 도로 {len(parsed_data['roads'])}개, 등고선 {len(parsed_data['contours'])}개")
    return parsed_data

if __name__ == "__main__":
    # 테스트 구동 코드
    # controller_v3.html에 있는 기본 키 적용
    API_KEY = "65A66471-B13B-3834-9402-4FF6681FDF22"
    
    # 서울시청 근처 예시 좌표
    CENTER_LNG = 126.9780
    CENTER_LAT = 37.5665
    RADIUS_M = 100
    
    # 결과 파싱
    result_data = parse_vworld_terrain_data(API_KEY, CENTER_LNG, CENTER_LAT, RADIUS_M)
    
    # JSON 파일로 산출 저장
    output_target = "vworld_parsed_data.json"
    with open(output_target, "w", encoding="utf-8") as f:
        json.dump(result_data, f, ensure_ascii=False, indent=2)
        
    print(f"💾 추출된 데이터를 '{output_target}' 에 저장했습니다.")
